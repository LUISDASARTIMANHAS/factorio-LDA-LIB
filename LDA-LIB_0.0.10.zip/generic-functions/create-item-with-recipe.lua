local createItem = require("base-functions.create-item")
local createRecipe = require("base-functions.create-recipe")

local Module = {}

-- @param name string O nome do item e receita (ex: "solar-painel").
-- @param subgroup grupo onde ele deve ser organizado na gui do jogador (ex: "intermediate-products").
-- @param stack_size quantidade do item por stack nos inventarios (ex: 50).
-- @param crafted_in categoria onde o item pode ser construido (ex: "advanced-crafting").
-- @param time tempo que demora para ser construido em segundos (ex: 10) 10s.
-- @param ingredients tabela de ingredientes que são necessarios para construir o item.
-- @param results tabela de saidas depois de construido o item.
-- @param alternative_unlock_methods quais outras techs desbloqueiam esse item.
-- @param isEnabled se o item ja deve vir com a receita desbloqueada.
function Module.createItemWithRecipe(name, subgroup, stack_size, crafted_in, time, ingredients, results,alternative_unlock_methods,isEnabled,pictures)
    local item = createItem.createItem(name,subgroup, stack_size,pictures)
    local recipe = createRecipe.createRecipe("icons",name, crafted_in, time, ingredients, results,alternative_unlock_methods,isEnabled,pictures)

    return {item, recipe}
end


-- example 
-- {
--             type = "item",
--             name = "quantum-teleporter-equipment",
--             icon = path_main .. "graphics/itens/quantum-teleporter-equipment-128.png",
--             icon_size = 128,
--             subgroup = "itens",
--             -- diz pro jogo que o equipamento deve ser colocado com o item especificado
--             place_as_equipment_result = "quantum-teleporter-equipment",
--             order = "a[quantum-teleporter-item]",
--             stack_size = 1
--         },
--         {
--             type = "recipe",
--             name = "quantum-teleporter-equipment",
--             category = "advanced-crafting",
--             enabled = false,
--             energy_required = 120,
--             ingredients = {
--                 {type = "item", name = "supercapacitor", amount = 4096},
--                 {type = "item", name = "tungsten-plate", amount = 256},
--                 {type = "item", name = "carbon-fiber", amount = 64},
--                 {type = "item", name = "quantum-processor", amount = 256}
--             },
--             results = {
--                 {type = "item", name = "quantum-teleporter-equipment", amount = 1}
--             },
--             alternative_unlock_methods = {"Quantum-Teleporter"}
--         }
--     }
return Module
