# Factorio-Mod-Template
Este e um template desenvolvido por luis das artimanhas, que tem como objetivo, fazer um template ou padronizar a criação dos arquivos de mod.
