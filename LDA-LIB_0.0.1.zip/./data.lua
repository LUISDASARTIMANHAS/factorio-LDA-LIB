require("audio/music-loader.lua")
require("data/recursos.lua")

-- presets Basicos do mods
require("graficos/style.lua")
require("data/grupos.lua")
