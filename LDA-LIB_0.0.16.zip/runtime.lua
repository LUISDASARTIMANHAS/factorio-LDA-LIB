return require("runtime.init")

