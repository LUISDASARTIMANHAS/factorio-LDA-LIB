local createEquipment = require("data-stage.builders.base.create-equipment-item")
local createRecipe = require("data-stage.builders.base.create-recipe")

local Module = {}

-- @param name string O nome do item e receita (ex: "solar-painel").
-- @param subgroup grupo onde ele deve ser organizado na gui do jogador (ex: "intermediate-products").
-- @param stack_size quantidade do item por stack nos inventarios (ex: 50).
-- @param crafted_in categoria onde o item pode ser construido (ex: "advanced-crafting").
-- @param time tempo que demora para ser construido em segundos (ex: 10) 10s.
-- @param ingredients tabela de ingredientes que são necessarios para construir o item.
-- @param results tabela de saidas depois de construido o item .
function Module.createEquipmentItemWithRecipe(name, subgroup, weight, crafted_in, time, ingredients, results,alternative_unlock_methods,isEnabled,pictures)
    local item = createEquipment.createEquipmentItem(name,subgroup, weight)
    local recipe = createRecipe.createRecipe("equipment",name, crafted_in, time, ingredients, results,alternative_unlock_methods,isEnabled,pictures)

    return {item, recipe}
end


-- example 
-- {
--             type = "item",
--             name = "quantum-teleporter-equipment",
--             icon = path_main .. "graphics/itens/quantum-teleporter-equipment-128.png",
--             icon_size = 128,
--             subgroup = "itens",
--             -- diz pro jogo que o equipamento deve ser colocado com o item especificado
--             place_as_equipment_result = "quantum-teleporter-equipment",
--             order = "a[quantum-teleporter-item]",
--             stack_size = 1
--         },
--         {
--             type = "recipe",
--             name = "quantum-teleporter-equipment",
--             categories = {"advanced-crafting"},
--             enabled = false,
--             energy_required = 120,
--             ingredients = {
--                 {type = "item", name = "supercapacitor", amount = 4096},
--                 {type = "item", name = "tungsten-plate", amount = 256},
--                 {type = "item", name = "carbon-fiber", amount = 64},
--                 {type = "item", name = "quantum-processor", amount = 256}
--             },
--             results = {
--                 {type = "item", name = "quantum-teleporter-equipment", amount = 1}
--             },
--             alternative_unlock_methods = {"Quantum-Teleporter"}
--         }
--     }
return Module
