--- LDA-LIB - Init
--- Biblioteca central que exporta todas as funções utilitárias.
--- Segue o padrão estático obrigatório do Factorio (require explícito).

local LDA = {}

---------------------------------------------------------------------
-- IMPORTAÇÕES DOS MÓDULOS
---------------------------------------------------------------------
local controlGetModPath = require("utils.control-get-mod-path")
local utils = require("utils.control-utils")
local utilsAmbientEffects = require("utils.control-ambent-effects")
local utilsEnergySource = require("utils.control-energy-sources")
local CANI = require("utils.control-animations")

-- BASE FUNCTIONS - FUNÇÕES BASE DO JOGO ABSTRAIDAS
local CAC = require("base-functions.autoplace-control")
local CO = require("base-functions.create-ore")
local CI = require("base-functions.create-item")
local CBI = require("base-functions.create-block-item")
local CIG = require("base-functions.create-item-group")
local CEI = require("base-functions.create-equipment-item")
local CF = require("base-functions.create-fluid")
local CG = require("base-functions.create-gas")
local CR = require("base-functions.create-recipe")
local CIS = require("base-functions.create-item-search")
local CE = require("base-functions.create-entity")
local FRL = require("base-functions.formatResultsList")
local TECH = require("base-functions.create-technology")
local TECHTRIGGER = require("base-functions.create-technology-trigger")
local controlResource = require("base-functions.resource")
local techUtil = require("utils.tech-util")

-- GENERIC FUNCTIONS - FUNÇÕES PRE PRONTAS QUE JA CRIAM TODO O CONJUNTO DO RECURSO, ITEM OU ENTIDADE. 
-- EM VEZ DE CRIAR UM POR UM COM AS BASE FUNCTIONS
local CIR = require("generic-functions/create-item-with-recipe")
local CFR = require("generic-functions/create-fluid-with-recipe")
local CBIR = require("generic-functions.create-block-item-with-recipe")
local CEIR = require("generic-functions.create-equipment-item-with-recipe")
local CGR = require("generic-functions.create-generic-recipe")

-- ADVANCED FUNCTIONS - VARIAÇOES DE FUNÇÕES BASE OU GENERIC FUNCTIONS, 
-- COMO TIPOS DE RECEITAS FEITAS E, MAQUINAS OU FORNALHAS OU TIPOS DE PESQUISAS VARIADAS
local CTWIR = require("functions.create-throw-in-water-item-with-recipe")
local CCMIR = require("functions.create-category-machines-item-with-recipe")
local CTTCE = require("functions.create-technology-trigger-craft-entity")
local CTTME = require("functions.create-technology-trigger-mine-entity")

---------------------------------------------------------------------
-- API PÚBLICA
---------------------------------------------------------------------

--- @class LDA.Functions
--- @field createOre fun(...) Cria um minério básico.
--- @field createItem fun(...) Cria um item simples.
--- @field createBlockItem fun(...) Cria um bloco estruturado.
--- @field createEquipmentItem fun(...) Cria um bloco estruturado.
--- @field createFluid fun(...) Cria um fluido.
--- @field createGas fun(...) Cria um gás.
--- @field createRecipe fun(...) Cria uma receita.
--- @field createItemSearch fun(...) Cria itens de pesquisa como kits cientificos.
--- @field createItemWithRecipe fun(...) Item + receita.
--- @field createFluidWithRecipe fun(...) Fluido + receita.
--- @field createBlockItemWithRecipe fun(...) Bloco + receita.
--- @field createSmeltingItemWithRecipe fun(...) Item especial de fundição.
--- @field createAssemblerItemWithRecipe fun(...) Máquina montadora customizada.
--- @field createTechnology fun(...) Cria tecnologias completas.
--- @field createGenericRecipe fun(...) Cria receita genérica flexível.

-- ISSO E NECESSARIO PORQUE CASO PRECISE ALTERAR UMA FUNÇÃO O USUARIO FINAL NÃO TERA SEU PROJETO QUEBRADO, POIS ISSO CRIA UMA CAMADA DE ABSTRAÇÃO.
LDA.functions = {
    utilsAnimations = CANI,
    utils = utils,
    utilsAmbientEffects = utilsAmbientEffects,
    utilsEnergySource = utilsEnergySource,
    techUtils = techUtil,
    getBasePath = controlGetModPath.getModPath,
    setBasePath = controlGetModPath.setBasePath,
    createAutoplaceControl = CAC.createAutoplaceControl,
    createResource = controlResource.createResource,
    createOre = CO.createOre,
    createItemGroup = CIG.createItemGroup,
    createItem = CI.createItem,
    createEquipmentItem = CEI.createEquipmentItem,
    createBlockItem = CBI.createBlockItem,
    createEntity = CE.createEntity,
    createFluid = CF.createFluid,
    createGas = CG.createGas,
    createRecipe = CR.createRecipe,
    createItemWithRecipe = CIR.createItemWithRecipe,
    createFluidWithRecipe = CFR.createFluidWithRecipe,
    createBlockItemWithRecipe = CBIR.createBlockItemWithRecipe,
    createEquipmentItemWithRecipe = CEIR.createEquipmentItemWithRecipe,
    createSmeltingItemWithRecipe = CCMIR.createSmeltingItemWithRecipe,
    createChemicalPlantItemWithRecipe = CCMIR.createChemicalPlantItemWithRecipe,
    createAssemblerItemWithRecipe = CCMIR.createAssemblerItemWithRecipe,
    createBiochamberItemWithRecipe = CCMIR.createBiochamberItemWithRecipe,
    createThrowInWaterItemWithRecipe = CTWIR.createThrowInWaterItemWithRecipe,
    createTechnology = TECH.createTechnology,
    createTechnologyTrigger = TECHTRIGGER.createTechnologyTrigger,
    createItemSearch = CIS.createItemSearch,
    createGenericRecipe = CGR.createGenericRecipe,
    createTechnologyCraftEntityTrigger = CTTCE.createTechnologyCraftEntityTrigger,
    createTechnologyMineEntityTrigger = CTTME.createTechnologyMineEntityTrigger,
    formatResultsList = FRL.formatResultsList,
}

---------------------------------------------------------------------
-- RETORNO
---------------------------------------------------------------------

return LDA.functions
